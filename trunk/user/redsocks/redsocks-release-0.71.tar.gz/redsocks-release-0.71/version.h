#ifndef VERSION_H_SUN_NOV_27_03_22_30_2011
#define VERSION_H_SUN_NOV_27_03_22_30_2011

extern const char* redsocks_version;

#endif // VERSION_H_SUN_NOV_27_03_22_30_2011
