// DeflateProps.cpp

#include "StdAfx.h"
