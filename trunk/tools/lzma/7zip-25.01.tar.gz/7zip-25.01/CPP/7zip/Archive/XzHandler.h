// XzHandler.h

#ifndef ZIP7_INC_XZ_HANDLER_H
#define ZIP7_INC_XZ_HANDLER_H

namespace NArchive {
namespace NXz {
 
}}

#endif
